from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField, StringField
from wtforms.validators import DataRequired

class selectForm(FlaskForm):
    student = SelectField("Student Name")
    submit = SubmitField("Load Student Info")


