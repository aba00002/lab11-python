import sqlite3
import webbrowser
import base64

from flask import Flask, render_template, request, url_for, redirect

from forms import selectForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'JOHN'

@app.route('/')
@app.route('/home')
def home():
    return render_template("index.html", title="Lab11")

@app.route('/findStudent', methods=['GET', 'POST'])
def findStudent():
    form = selectForm()
    con = sqlite3.connect('week10.db')
    cur = con.cursor()
    cur.execute("select id, student from Lab10 where student is not null order by student ASC")
    place = cur.fetchall()
    studentList = list(place)
    form.student.choices = studentList
    if request.method == 'POST':
        oneStudent = form.student.data
        cur2 = con.cursor()
        cur2.execute("select id, link from Lab10 where id = {}".format(int(oneStudent)))
        name = cur2.fetchone()
        decodedValue = base64.urlsafe_b64decode(name[1]).decode('utf-8')
        webbrowser.open(decodedValue, new=2)
        cur2.close()
    cur.close()
    return render_template("findStudent.html", form=form, title="Select the student")

@app.route('/displayAll')
def displayAll():
    con = sqlite3.connect("week10.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()

    cur.execute("select * from Lab10")
    dataRows = cur.fetchall()
    data_list = []
    for row in dataRows:
        data_list.append(dict(row))
    for row in data_list:
        row['Link'] = base64.b64decode(row['Link']).decode()

    return render_template("displayAll.html", rows=data_list, title="A TABLE OF ALL THE STUDENTS IN CLASS")

if __name__ == '__main__':
    app.run()